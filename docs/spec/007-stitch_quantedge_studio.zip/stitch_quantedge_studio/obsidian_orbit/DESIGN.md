# Design System Specification: The Void & The Neon

## 1. Overview & Creative North Star
**Creative North Star: "The Galactic Monolith"**

This design system is built upon the concept of high-performance technical precision set against the infinite depth of deep space. We are moving away from the "friendly" rounded web of the last decade and returning to a high-contrast, editorial aesthetic that favors architectural sharp edges and atmospheric depth.

To achieve a signature look, we avoid standard grid-row layouts. Instead, we embrace **intentional asymmetry** and **tonal layering**. The interface should feel like a sophisticated flight deck or a high-end data terminal: cold, precise, and undeniably premium. We break the "template" look by overlapping glass panels and using the typography scale to create massive contrast between technical data and large-scale editorial headers.

---

## 2. Colors & Surface Architecture
The color palette is anchored in absolute darkness, utilizing vibrant accents to signify interaction and data flow.

### Color Tokens
*   **Primary (Neon Violet):** `#ba9eff` — Used for high-priority calls to action and critical brand moments.
*   **Secondary (Electric Indigo):** `#9492ff` — Used for supporting interactive elements and data visualization.
*   **Tertiary (Cyan Tech):** `#69daff` — Reserved for technical status indicators and informational accents.
*   **Background:** `#0e0e0e` — The "void" that provides the foundation for the entire experience.

### The "No-Line" Rule
Explicitly prohibited: 1px solid borders for sectioning or containment. 
Boundaries in this design system must be defined through **Background Tonal Shifts**. To separate a sidebar from a main content area, do not draw a line. Instead, place a `surface-container-low` (#131313) panel against the `surface` (#0e0e0e) background. 

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers of obsidian and frosted glass.
*   **Surface Container Lowest (#000000):** For deep "wells" or background-level content.
*   **Surface Container (#1a1919):** Your standard card or section background.
*   **Surface Container Highest (#262626):** For floating elements or top-level navigation that needs to "pop" against the void.

### The "Glass & Gradient" Rule
To elevate the system beyond flat blocks, utilize **Glassmorphism** for all floating overlays.
*   **Effect:** `background: rgba(44, 44, 44, 0.4); backdrop-filter: blur(20px);`
*   **CTAs:** Use subtle linear gradients for `primary` buttons (e.g., `#ba9eff` to `#8455ef`) to provide a "pulsing" energy that flat colors lack.

---

## 3. Typography
The typography is a dialogue between brutalist technicality and clean modernism.

### The Scale
*   **Display (Space Grotesk):** 3.5rem (LG) to 2.25rem (SM). High-contrast, tight tracking (-2%). Use these for impact and brand storytelling.
*   **Headline (Space Grotesk):** 2rem to 1.5rem. Used for technical sections and data headers.
*   **Body (Inter):** 1rem (LG) to 0.75rem (SM). The workhorse. Inter provides a neutral, highly readable counterpoint to the aggressive Space Grotesk.
*   **Labels (Space Grotesk):** 0.75rem. All-caps for a "heads-up display" (HUD) feel.

**Editorial Implementation:** Do not center-align long-form text. Use left-aligned, asymmetrical layouts. Allow for "dead space"—large areas of `#050505`—to emphasize the importance of the content that *is* present.

---

## 4. Elevation & Depth
In this design system, elevation is conveyed through light and transparency, never through heavy structural boxes.

### The Layering Principle
Depth is achieved by stacking `surface-container` tiers. A `surface-container-lowest` card sitting on a `surface-container-low` background creates a "sunken" effect. Conversely, a `surface-bright` element creates a "raised" effect.

### Ambient Shadows
Shadows are rarely used. When a "floating" effect is mandatory (e.g., a dropdown menu), use a **Tinted Ambient Shadow**:
*   **Color:** `#ba9eff` at 5% opacity.
*   **Blur:** 40px–60px.
*   **Spread:** -5px.
This mimics the glow of a neon light source rather than a physical shadow.

### The "Ghost Border" Fallback
If a visual container is required for accessibility, use a **Ghost Border**:
*   **Stroke:** 1px.
*   **Color:** `outline-variant` (#494847) at 15% opacity.
*   **Rule:** Never use 100% opaque borders.

---

## 5. Components

### Buttons
*   **Primary:** Sharp corners (0px). Gradient fill from `primary` to `primary-dim`. White text (`on-primary`).
*   **Secondary:** Sharp corners (0px). Ghost border (15% opacity). No background fill unless hovered.
*   **States:** On hover, primary buttons should increase their glow (inner shadow/drop shadow of the same color).

### Input Fields
*   **Style:** Minimalist. No four-sided border. Use a `surface-variant` (#262626) background with a 2px bottom-accent in `primary` only when the field is focused.
*   **Corners:** Strictly 0px.

### Cards & Lists
*   **The Divider Prohibition:** Forbid the use of divider lines between list items. Use vertical white space (16px, 24px, or 32px) and subtle background shifts to define rows.
*   **Glass Panels:** High-importance cards should use the Glassmorphism effect described in Section 2.

### Signature Component: The HUD Chip
*   Small, all-caps labels using `label-sm` (Space Grotesk). Used for metadata. Background is always `surface-container-high` with a 1px left-side accent bar in `tertiary`.

---

## 6. Do's and Don'ts

### Do
*   **DO** use 0px border-radius everywhere. There are no circles or rounded rects in deep space.
*   **DO** use raw black (#000000) for deep backgrounds to maximize OLED contrast.
*   **DO** lean into "Technical Brutalism"—let the typography do the heavy lifting.

### Don't
*   **DON'T** use standard grey shadows. They look "muddy" in high-contrast dark mode.
*   **DON'T** use 1px solid, opaque borders. It breaks the immersive, "floating" feel of the system.
*   **DON'T** crowd the UI. High-performance design requires "breathing room" to allow the eye to navigate complex data quickly.
*   **DON'T** use center-alignment for headers. Keep the layout grounded in a strong, left-heavy editorial grid.