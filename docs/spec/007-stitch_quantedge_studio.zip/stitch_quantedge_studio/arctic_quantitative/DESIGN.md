# Design System Strategy: The Arctic Precision Framework

## 1. Overview & Creative North Star: "The Glacial Lens"
This design system is built for a quantitative environment where clarity is the ultimate luxury. Our Creative North Star is **"The Glacial Lens"**—an aesthetic that prioritizes extreme visibility, structural transparency, and a cold, professional discipline. 

To move beyond the "SaaS template" look, we reject the standard box-and-border container model. Instead, we embrace **intentional asymmetry** and **tonal layering**. We treat the UI as a high-end editorial piece: large, geometric display type meets high-density data tables. The "Arctic" feel comes from the tension between expansive white space (breathing room) and hyper-dense information clusters. Elements should feel like they are etched into ice or suspended in clear water, rather than pasted onto a screen.

---

## 2. Colors: Tonal Architecture
The palette is a sophisticated range of "cool neutrals" designed to reduce eye strain during long analytical sessions while maintaining a premium, "quant-studio" authority.

### The "No-Line" Rule
**Borders are a design failure in this system.** You are prohibited from using 1px solid borders for sectioning or layout containment. Boundaries must be defined solely through:
- **Background Shifts:** A `surface_container_low` section sitting against a `surface` background.
- **Tonal Transitions:** Defining an area by its relative depth in the stacking order.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the surface tiers to create "nested" depth:
- **Base Layer:** `surface` (#f7f9fb) for the primary application background.
- **Structural Zones:** `surface_container` (#eceef0) for sidebars or navigation rails.
- **Interactive Planes:** `surface_container_lowest` (#ffffff) for the primary "active" workspace or cards. This creates a soft, natural lift.

### The "Glass & Gradient" Rule
To inject "soul" into the analytical environment:
- **Floating Elements:** Use `surface_container_lowest` at 80% opacity with a `20px` backdrop-blur for modals or dropdowns.
- **Primary CTAs:** Do not use flat blue. Apply a subtle linear gradient from `primary` (#006399) to `primary_container` (#4ca2e3) at a 135-degree angle. This adds a "lithographic" depth that feels high-end.

---

## 3. Typography: Editorial Authority
We pair the geometric rigor of **Space Grotesk** with the neutral clarity of **Inter**.

- **Display & Headlines (Space Grotesk):** Used for "The Statement." Large-scale display sizes (`display-lg` at 3.5rem) should use tight letter-spacing (-0.02em) to feel architectural. Use these for key data highlights or section headers.
- **Body & Labels (Inter):** The "Workhorse." All data tables, terminal outputs, and functional text use Inter. 
- **The Hierarchy Strategy:** Use `headline-sm` in Space Grotesk for card titles, but immediately drop to `label-md` in Inter for metadata. This "high-low" contrast creates an editorial feel that distinguishes us from standard enterprise software.

---

## 4. Elevation & Depth: Atmospheric Layering
Shadows and lines are messy; we prefer **Tonal Layering**.

- **The Layering Principle:** Depth is achieved by stacking. A `surface_container_lowest` (#ffffff) card placed on top of a `surface_container_low` (#f2f4f6) background provides all the separation a user needs without visual clutter.
- **Ambient Shadows:** If a "floating" state is required (e.g., a dragged tile), use an extra-diffused shadow: `0px 12px 32px rgba(25, 28, 30, 0.04)`. The shadow must use a tint of `on_surface` to feel like natural light passing through ice.
- **The "Ghost Border" Fallback:** If a container sits on a background of the same color (e.g., in high-density data views), use a **Ghost Border**: `outline_variant` (#bec8d2) at 15% opacity. It should be felt, not seen.

---

## 5. Components: Precision Primitives

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on_primary` text, `md` roundedness (0.375rem).
- **Secondary:** `surface_container_high` fill with `primary` text. No border.
- **Tertiary:** Transparent background, `primary` text, bold `label-md` typography.

### Data Inputs
- **Fields:** `surface_container_low` background with a `Ghost Border` that transitions to a 2px `primary` bottom-stroke on focus.
- **Density:** Use `body-sm` for input text to maintain high data density in quant dashboards.

### Cards & Lists
- **The Divider Ban:** Never use horizontal rules (`<hr>`). Separate list items using 4px of vertical whitespace or a subtle hover state shift to `surface_container_highest`.
- **Nesting:** Data cards should always be `surface_container_lowest` to pop against the `surface` background.

### Quant-Specific Components
- **Data Strips:** Use `surface_container_high` as a background for "read-only" telemetry data to distinguish it from interactive inputs.
- **Trend Indicators:** Use `tertiary` (#8a5100) for warnings and `primary` (#006399) for positive growth—avoiding the standard "Traffic Light" (Red/Green) palette to keep the "Arctic" aesthetic pure, unless the error is critical (`error` #ba1a1a).

---

## 6. Do's and Don'ts

### Do:
- **Embrace Asymmetry:** Align a large `display-md` title to the left, but keep the data grid justified to the right. It feels more "bespoke."
- **Use "Space" as a Tool:** If two sections feel cluttered, don't add a line—add 32px of whitespace.
- **Respect the Type Scale:** Use `label-sm` for captions. Tiny, crisp text in Inter looks incredibly professional when paired with wide margins.

### Don't:
- **Don't use pure black:** Always use `on_surface` (#191c1e) for text. Pure black is too harsh for the "Arctic" theme.
- **Don't use 100% opaque borders:** They break the "Glacial Lens" effect and create visual "noise" that interferes with data reading.
- **Don't round everything:** Stick to `sm` (0.125rem) or `md` (0.375rem) corners. Excessive rounding (like `xl`) feels too "consumer-tech" and lacks the precision required for a quant studio.