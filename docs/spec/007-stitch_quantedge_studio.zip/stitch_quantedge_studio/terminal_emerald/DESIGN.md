# Design System Documentation

## 1. Overview & Creative North Star: "The Kinetic Command Line"

This design system is a sophisticated departure from the "hacker aesthetic" cliché. It moves beyond the flat, 1980s terminal look into a realm of **High-End Digital Brutalism**. The Creative North Star is defined as **"The Kinetic Command Line"**—an interface that feels like an elite, high-velocity data environment where raw code meets editorial elegance.

We achieve this by pairing the rigid, technical structure of monospaced-adjacent typography with a deep, liquid sense of space. The layout rejects traditional "boxed" grids in favor of intentional asymmetry and "The Void"—using the charcoal background (`#0e0e0e`) as a canvas for high-contrast, luminescent emerald elements that appear to float and pulse.

---

## 2. Colors: Phosphor & Void

The palette is rooted in a high-contrast relationship between deep charcoal and vibrant greens. It mimics the glow of old-school cathode-ray tubes but with modern tonal depth.

### The "No-Line" Rule
**Explicit Instruction:** You are prohibited from using 1px solid borders for sectioning. Boundaries must be defined solely through background color shifts. 
- To separate a sidebar, use `surface-container-low` (#131313) against the `surface` background (#0e0e0e). 
- To define a content area, use `surface-container-highest` (#262626). 
- If the layout feels "lost," use spacing, not lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical plates of obsidian glass.
- **Base Layer:** `surface` (#0e0e0e)
- **Secondary Tiers:** `surface-container-low` (#131313) or `surface-container-high` (#201f1f).
- **The Glow Effect:** Use `primary` (#9cff93) sparingly for critical data points. It should feel like a "phosphor burn" on the screen.

### The "Glass & Gradient" Rule
To prevent the UI from feeling "flat," use Glassmorphism on floating elements (modals, dropdowns). Apply `surface-variant` (#262626) with a 20px-40px backdrop-blur. For main CTAs, apply a subtle linear gradient from `primary` (#9cff93) to `primary-container` (#00fc40) at a 45-degree angle to provide a sense of "visual soul."

---

## 3. Typography: Technical Authority

We use **Space Grotesk** across all scales. While not a strict monospace, its geometric quirks provide a "techno-editorial" feel that maintains high legibility while nodding to terminal origins.

- **Display Scales:** Use `display-lg` (3.5rem) with tight letter spacing (-0.02em) for hero moments. This should feel like a massive data read-out.
- **The Label System:** Labels (`label-md`, `label-sm`) are the backbone of this system. Use them for metadata, timestamps, and secondary navigation. Always use uppercase for `label-sm` to lean into the "terminal" aesthetic.
- **Hierarchy:** Contrast is king. Pair a `display-sm` headline with a `label-md` timestamp to create an intentional gap in scale, emphasizing the "data-rich" nature of the system.

---

## 4. Elevation & Depth

In this system, 0px border radii are mandatory. Sharp edges suggest precision. Depth is achieved through **Tonal Layering**, not structural shadows.

- **The Layering Principle:** Stack containers to create hierarchy. A `surface-container-highest` card sitting on a `surface-container-low` section creates a sharp, technical lift.
- **Ambient Shadows:** When an element must float (e.g., a command palette), use an extra-diffused shadow. 
    - **Color:** `on-surface` (#ffffff) at 4% opacity. 
    - **Blur:** 60px.
    - **Purpose:** This creates a "bloom" effect rather than a traditional drop shadow.
- **The "Ghost Border" Fallback:** If accessibility requires a container definition, use the `outline-variant` (#484847) at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Buttons
- **Primary:** Solid `primary` (#9cff93) with `on-primary` (#006413) text. Sharp 0px corners. On hover, apply a 2px "bloom" (outer glow) using the primary color.
- **Secondary:** Outlined with a "Ghost Border" and `primary` text.
- **Tertiary:** Text only, using `primary` color, accompanied by a trailing character like `_` or `>` to mimic a cursor.

### Input Fields
Text inputs should not be boxes. Use a `surface-container-highest` background with a bottom-only 2px accent of `outline` (#767575). When focused, the bottom accent transforms into `primary` (#9cff93).

### Cards & Lists
**Forbid the use of divider lines.** 
- Separate list items using a 12px vertical gap and a background shift to `surface-container-low` on hover. 
- Use "The Cursor" (a 4px wide `primary` vertical bar) on the left edge of a selected list item to indicate focus.

### Additional Component: "The Data Ticker"
A horizontal or vertical scrolling stream of metadata using `label-sm` in `secondary` (#b5f3a2). This provides the "Matrix" sense of constant data flow without cluttering the main functional UI.

---

## 6. Do's and Don'ts

### Do:
- **Do** embrace "The Void." Large areas of `#0e0e0e` make the emerald elements feel more premium.
- **Do** use intentional asymmetry. Align some text to the far left and metadata to the far right to create tension.
- **Do** use `primary-dim` (#00ec3b) for long-form reading to reduce eye strain compared to the full-vibrant primary.

### Don't:
- **Don't** use rounded corners. Ever. (0px is the absolute rule).
- **Don't** use standard "Grey" for shadows. Use low-opacity whites or greens to mimic light emission.
- **Don't** use dividers or 1px lines. If the UI feels cluttered, increase the white space (the "Void").
- **Don't** use "Error Red" indiscriminately. Use `error` (#ff7351) only for critical system failures to maintain the emerald-dominated brand identity.

### Accessibility Note:
Ensure that `on-background` (#ffffff) is used for body text to maintain a high contrast ratio against the `#0e0e0e` surface. The emerald `primary` should primarily be used for interactive elements and highlights.